config =    {
            'neck_architecture' :[16384,512,256,4],
            'head_architecture' :[4,63],
            'neck_lr'           : 1e-4,
            'head_lr'           : 1e-4,
            'batch_size'        : 256
            }